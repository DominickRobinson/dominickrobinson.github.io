public class Queen extends Piece{
  
  public Queen(boolean isWhite){
    super(isWhite);
    name = "queen";
    if (color == true)
      symbol = 'q';
    else
      symbol = 'Q';
  }
  
}