public class Rook extends Piece{
  
  public Rook(boolean isWhite){
    super(isWhite);
    name = "rook";
    if (color == true)
      symbol = 'r';
    else
      symbol = 'R';
  }
  
}