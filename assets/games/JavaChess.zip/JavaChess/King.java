public class King extends Piece{
  
  public King(boolean isWhite){
    super(isWhite);
    name = "king";
    if (color == true)
      symbol = 'k';
    else
      symbol = 'K';
  }
  
}