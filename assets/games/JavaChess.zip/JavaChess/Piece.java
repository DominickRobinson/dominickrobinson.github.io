public class Piece{
  
  String name;
  boolean color;
  boolean selected = false;
  char symbol;
  boolean hasMoved = false;
  int whenMoved = 0;
  
  public Piece(boolean isWhite){
    color = isWhite;
  }
  
  public String getName(){
    return name;
  }
  
  public boolean getColor(){
    return color;
  }

  
  public char getSymbol(){
    return symbol;
  }
  
  public boolean getMoved(){
    return hasMoved;
  }
  
  public void resetMoved(){
    whenMoved = 0;
    hasMoved = false;
  }
  
  public int getWhenMoved(){
    return whenMoved;
  }
  
  public void moved(int when){
    hasMoved = true;
  }
  
}