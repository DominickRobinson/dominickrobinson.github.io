public class Pawn extends Piece{
  
  public Pawn(boolean isWhite){
    super(isWhite);
    name = "pawn";
    if (color == true)
      symbol = 'p';
    else
      symbol = 'P';
  }
  
}