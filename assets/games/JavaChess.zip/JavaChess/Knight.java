public class Knight extends Piece{
  
  public Knight(boolean isWhite){
    super(isWhite);
    name = "knight";
    if (color == true)
      symbol = 'n';
    else
      symbol = 'N';
  }
  
}