//Dominick Robinson
import java.util.Scanner;
import java.util.ArrayList;

public class Chess{
  
  public static void main(String[] args){
    Scanner reader = new Scanner(System.in);                   
    
    
    //player one's pieces
    Piece p1 = new Pawn(true);
    Piece p2 = new Pawn(true);
    Piece p3 = new Pawn(true);
    Piece p4 = new Pawn(true);
    Piece p5 = new Pawn(true);
    Piece p6 = new Pawn(true);
    Piece p7 = new Pawn(true);
    Piece p8 = new Pawn(true);
    Piece p9 = new Rook(true);
    Piece p10 = new Knight(true);
    Piece p11 = new Bishop(true);
    Piece p12 = new Queen(true);
    Piece p13 = new King(true);
    Piece p14 = new Bishop(true);
    Piece p15 = new Knight(true);
    Piece p16 = new Rook(true);
    
    //player two's pieces
    Piece P1 = new Pawn(false);
    Piece P2 = new Pawn(false);
    Piece P3 = new Pawn(false);
    Piece P4 = new Pawn(false);
    Piece P5 = new Pawn(false);
    Piece P6 = new Pawn(false);
    Piece P7 = new Pawn(false);
    Piece P8 = new Pawn(false);
    Piece P9 = new Rook(false);
    Piece P10 = new Knight(false);
    Piece P11 = new Bishop(false);
    Piece P12 = new Queen(false);
    Piece P13 = new King(false);
    Piece P14 = new Bishop(false);
    Piece P15 = new Knight(false);
    Piece P16 = new Rook(false);
    
    //keeps record of all moves played throughout match
    ArrayList<Piece[][]> match = new ArrayList<Piece[][]>();
          
    //puts pieces on board
    Piece[][] board = {
      {P9, P10, P11, P12, P13, P14, P15, P16},
      {P1, P2, P3, P4, P5, P6, P7, P8},
      {null, null, null, null, null, null, null, null},
      {null, null, null, null, null, null, null, null},
      {null, null, null, null, null, null, null, null},
      {null, null, null, null, null, null, null, null},
      {p1, p2, p3, p4, p5, p6, p7, p8},
      {p9, p10, p11, p12, p13, p14, p15, p16},
    };
    
    
    boolean classic = true;
    
    
                                                                                          
    System.out.println("                                            Welcome to...\n\n" +
                       
                       "                        .d8888b.    888    888   8888888888    .d8888b.     .d8888b.  \n" +
                       "                       d88P  Y88b   888    888   888          d88P  Y88b   d88P  Y88b \n" +
                       "                       888    888   888    888   888          Y88b.        Y88b.      \n" +
                       "                       888          8888888888   8888888       \"Y888b.      \"Y888b.   \n" +
                       "                       888          888    888   888              \"Y88b.       \"Y88b. \n" +
                       "                       888    888   888    888   888                \"888         \"888 \n" +
                       "                       Y88b  d88P   888    888   888          Y88b  d88P   Y88b  d88P \n" +
                       "                        \"Y8888P\"    888    888   8888888888    \"Y8888P\"     \"Y8888P\"  \n\n\n"                                      
                      );
    
                                                                                      

    
    
    System.out.println("\nHello, and welcome to my chess program!\n");
    
    //gets player 1's name
    System.out.println("What is your name, Player 1?\n(Player 1 will move first.)");
    String n1 = reader.nextLine();
    
    //gets player 2's name
    System.out.println("What is your name, Player 2?\n(Player 2 will move second.)");
    String n2 = reader.nextLine();
    
    //choose graphics
/*    System.out.println("Would you like to play 2D or 3D chess?");
    String response = reader.nextLine();
    while (!response.toLowerCase().equals("3d") && !response.toLowerCase().equals("2d")){
      System.out.println("You must type either \"2D\" or \"3D\".");
      response = reader.nextLine();
    }
    
    if (response.toLowerCase().equals("3d"))
      classic = false;
 */
    
    System.out.println("\n\nBefore you begin play, here are the controls you should know:");
    
    
    controls();
    
    System.out.println("Now that you know the controls, hit enter to play! Good luck!\n\n\n\n\n\n" +
                       "P.S. Press \"g\" while playing for a surprise :)\n");
    
    //forces user to press enter after reading the directions
    String stall = reader.nextLine();
    
    System.out.println("\n");
  
    
    
    Piece[][] temp;
    boolean isWhite = true;
    int cursor = 44;
    int selection = 99;
    int destination = 99;
    String input;
    boolean pieceSelected = false;
    boolean gameOver = false;
    boolean whiteWon = true;
    boolean stalemate = false;
    
    char graphics = 'g';
    char sel = 'q';
    char dest = 'e';
    
    //loops until game ends
    while (!gameOver){
      
      
      //prints board
      if (classic)
        printBoard(board, cursor, isWhite);
      else
        printBoard3D(board, cursor, selection);
      if (isWhite)
        System.out.println("It is " + n1 + "'s turn to move.");
      else
        System.out.println("It is " + n2 + "'s turn to move.");
      if (match.size()%2 == 0)
        System.out.println("Turn count: " + ((match.size()-1)/2 + 1) + ".a.\n");
      else
        System.out.println("Turn count: " + ((match.size()-1)/2 + 1) + ".b.\n");
      System.out.println("Piece selected: " + pieceSelected + "\n");
      
      System.out.println("To see a list of commands, type \"controls\".\n");
      
      
      //gets input from player
      input = reader.nextLine();
      while (input.equals(""))
        input = reader.nextLine();
      input = input.toLowerCase();
      cursor = moveCursor(cursor, input, isWhite);
      
      if (input.indexOf(graphics) != -1)
        classic = !classic;
      
      //occurs if player chooses a piece to move
      if (input.indexOf(sel) != -1){
        if (board[getY(cursor)][getX(cursor)] == null)
          System.out.println("You must select a piece.");
        else{
          if (board[getY(cursor)][getX(cursor)].getColor() != isWhite)
            System.out.println("You may not select your opponent's piece.");
          else{
            pieceSelected = true;
            selection = cursor;
          }
        }
      }
      
      
      //occurs if player chooses where to move piece
      if (input.indexOf(dest) != -1){
        if (pieceSelected){
          if (legal(board, selection, cursor, isWhite)){
            destination = cursor;
            cursor = 44;
            temp = board;
            board = update(board, selection, destination, isWhite, classic);
            board[getY(destination)][getX(destination)].moved(match.size());
            match.add(board);
            board = temp;
            selection = 99;
            isWhite = !isWhite;
            pieceSelected = false;
            board = invertBoard(board);
          }
          else
            System.out.println("That move is illegal. Please make a legal move.");
        }
        else
          System.out.println("Please select a piece before you make your move.");
      }
      
      
      //unique commands to help player or end the game
      if (input.equals("rules"))
        rules();
      
      if (input.equals("controls"))
        controls();
      
      if (input.equals("pieces"))
        pieces(classic);
      
      if (input.equals("stalemate")){
        stalemate = true;
        gameOver = true;
      }
      
      if (input.equals("resign")){
        gameOver = true;
        if (isWhite)
          whiteWon = false;
        else
          whiteWon = true;
      }
      
      if (input.equals("u")){
        if (match.size() != 1){
          board = match.get(match.size() - 2);
          board = invertBoard(board);
          match.remove(match.size() - 1);
          for (int x = 0; x < 8; x++){
            for (int y = 0; y < 8; y++){
              if (board[y][x] != null && board[y][x].getWhenMoved() == match.size())
                board[y][x].resetMoved();
            }
          }
          isWhite = !isWhite;
          pieceSelected = false;
        }
      }
      
      


        
      
      
    }
    
    //checks how the game ended
    if (stalemate)
      System.out.println("\n\n\nLooks like it's a draw...");
    else{
      if (whiteWon)
        System.out.println("\n\n\n " + n1 + " wins!");
      else
        System.out.println("\n\n\n" + n2 + " wins!");
    }
    
    //asks player if they want to see replay of the match
    System.out.println("Would you like to review the match? (yes or no)");
    String review = reader.nextLine();
    review = review.toLowerCase();
    while (review.equals("yes") == false && review.equals("no") == false){
      System.out.println("Please say either yes or no.");
      review = reader.nextLine();
      review = review.toLowerCase();
    }
    if (review.equals("yes"))
      printMatch(match);
    
    
  }
 
  
  public static void printMatch(ArrayList<Piece[][]> match){
    
    for (Piece[][] board : match) {
      printBoard(board, 99, true);
    }
        
  }
  
  
  //compilation of movement rules for all pieces
  public static boolean legal(Piece[][] board, int selection, int destination, boolean isWhite){
    
    //cant keep piece on same square
    if (selection == destination){
      System.out.println("You must move the piece you selected to a different square.");
      return false;
    }
    
    //cant capture own piece
    if (board[getY(destination)][getX(destination)] != null && board[getY(destination)][getX(destination)].getColor() == isWhite){
      System.out.println("You may not capture your own piece."); 
      return false;
    }
    
    //calls pawn rules
    if (board[getY(selection)][getX(selection)].getName().equals("pawn"))
      return canMovePawn(board, selection, destination, isWhite);
    //calls knight rules
    if (board[getY(selection)][getX(selection)].getName().equals("knight"))
      return canMoveKnight(board, selection, destination, isWhite);
    //calls bishop rules
    if (board[getY(selection)][getX(selection)].getName().equals("bishop"))
      return canMoveDiagonally(board, selection, destination, isWhite);
    //calls rook rules
    if (board[getY(selection)][getX(selection)].getName().equals("rook"))
      return canMoveStraight(board, selection, destination, isWhite);
    //calls queen rules
    if (board[getY(selection)][getX(selection)].getName().equals("queen"))
      return (canMoveStraight(board, selection, destination, isWhite) || canMoveDiagonally(board, selection, destination, isWhite));
    //calls king rules
    if (board[getY(selection)][getX(selection)].getName().equals("king"))
      return canMoveKing(board, selection, destination, isWhite);
    
    return true;
    
  }
  
  //pawn rules
  public static boolean canMovePawn(Piece[][]board, int selection, int destination, boolean isWhite){
    
    //pawn can move 2 spaces if hasnt moved already
    if (getY(selection) == 6){
      if (selection - destination == 2){
        if (board[getY(selection)-1][getX(selection)] == null && board[getY(selection)-2][getX(selection)] == null){
          return true;
        }
      }
    }
    
    //pawn moves 1 space normally
    if (selection - destination == 1){
      if (board[getY(selection)-1][getX(selection)] == null){
        return true;
      }
    }
    
    //pawn can capture diagonally
    if (Math.abs(getX(selection) - getX(destination)) == 1 && getY(selection) - getY(destination) == 1 && board[getY(destination)][getX(destination)] != null && board[getY(destination)][getX(destination)].getColor() != isWhite)
      return true;
    
    //en passante
    
    /*
     * insert code here
     */
    
    return false;
    
  }
  
  //knight rules
  public static boolean canMoveKnight(Piece[][] board, int selection, int destination, boolean isWhite){
    
    //knight moves in an L shape in any direction
    return ((Math.abs(getY(destination)-getY(selection)) == 2 && Math.abs(getX(destination)-getX(selection)) == 1)||(Math.abs(getY(destination)-getY(selection)) == 1 && Math.abs(getX(destination)-getX(selection)) == 2));
    
  }
  
  //rules for bishop and queen
  public static boolean canMoveDiagonally(Piece[][] board, int selection, int destination, boolean isWhite){
    
    if (Math.abs(getX(selection) - getX(destination)) != Math.abs(getY(selection) - getY(destination)))
      return false;
    
    if (getX(selection) > getX(destination)){
      
      if (getY(selection) > getY(destination)){
        if (selection - 11 != destination){
          if (board[getY(selection) - 1][getX(selection) - 1] == null)
            return canMoveDiagonally(board, selection - 11, destination, isWhite);
        }
        else{
          if (board[getY(destination)][getX(destination)] == null || board[getY(destination)][getX(destination)].getColor() != isWhite)
            return true;
        }
      }
      else{
        
        if (selection - 9 != destination){
          if (board[getY(selection) + 1][getX(selection) - 1] == null)
            return canMoveStraight(board, selection - 9, destination, isWhite);
        }
        else{
          if (board[getY(destination)][getX(destination)] == null || board[getY(destination)][getX(destination)].getColor() != isWhite)
            return true;
        }
      }
    }
    
    else{
      
      if (getY(selection) > getY(destination)){
        if (selection + 9 != destination){
          if (board[getY(selection) - 1][getX(selection) + 1] == null)
            return canMoveDiagonally(board, selection + 9, destination, isWhite);
        }
        else{
          if (board[getY(destination)][getX(destination)] == null || board[getY(destination)][getX(destination)].getColor() != isWhite)
            return true;
        }
      }
      else{
        
        if (selection + 11 != destination){
          if (board[getY(selection) + 1][getX(selection) + 1] == null)
            return canMoveStraight(board, selection + 11, destination, isWhite);
        }
        else{
          if (board[getY(destination)][getX(destination)] == null || board[getY(destination)][getX(destination)].getColor() != isWhite)
            return true;
        }
      }
    }
    
    return false;
    
  }
  
  //rules for rook and queen
  public static boolean canMoveStraight(Piece[][] board, int selection, int destination, boolean isWhite){
    
    if (getX(selection) == getX(destination)){
      
      if (getY(selection) > getY(destination)){
        if (selection - 1 != destination){
          if (board[getY(selection) - 1][getX(selection)] == null)
            return canMoveStraight(board, selection - 1, destination, isWhite);
        }
        else{
          if (board[getY(destination)][getX(destination)] == null || board[getY(destination)][getX(destination)].getColor() != isWhite)
            return true;
        }
      }
      else{
        
        if (selection + 1 != destination){
          if (board[getY(selection) + 1][getX(selection)] == null)
            return canMoveStraight(board, selection + 1, destination, isWhite);
        }
        else{
          if (board[getY(destination)][getX(destination)] == null || board[getY(destination)][getX(destination)].getColor() != isWhite)
            return true;
        }
      }
    }
    
    if (getY(selection) == getY(destination)){
      
      if (getX(selection) > getX(destination)){
        if (selection - 10 != destination){
          if (board[getY(selection)][getX(selection) - 1] == null)
            return canMoveStraight(board, selection - 10, destination, isWhite);
        }
        else{
          if (board[getY(destination)][getX(destination)] == null || board[getY(destination)][getX(destination)].getColor() != isWhite)
            return true;
        }
      }
      else{
        if (selection + 10 != destination){
          if (board[getY(selection)][getX(selection) + 10] == null)
            return canMoveStraight(board, selection + 10, destination, isWhite);
        }
        else{
          if (board[getY(destination)][getX(destination)] == null || board[getY(destination)][getX(destination)].getColor() != isWhite)
            return true;
        }
      }
    }
    
    return false;
    
  }
  
  //rules for king
  public static boolean canMoveKing(Piece[][] board, int selection, int destination, boolean isWhite){
    
    
    //add castling rules later too lazy to do that rn
    if (isWhite){
      if (destination == 27){
        if (board[7][4].getMoved() == false && board[7][0].getMoved() == false && board[7][1] == null && board[7][2] == null && board[7][3] == null){
          return true;
        }
      }
      if (destination == 67){
        if (board[7][4].getMoved() == false && board[7][7].getMoved() == false && board[7][5] == null && board[7][6] == null){
          return true;
        }
      }
    }
    else{
      if (destination == 17){
        if (board[7][3].getMoved() == false && board[7][0].getMoved() == false && board[7][1] == null && board[7][2] == null){
          return true;
        }
      }
      if (destination == 57){
        if (board[7][3].getMoved() == false && board[7][7].getMoved() == false && board[7][6] == null && board[7][5] == null && board[7][4] == null){
          return true;
        }
      }
    }
  
      
    //king can normally move 1 square in any direction
    return (Math.abs(getY(destination)-getY(selection)) <= 1 && Math.abs(getX(destination)-getX(selection)) <= 1);
    
  }
  
  
  
  
  public static Piece[][] update(Piece[][] board, int selection, int destination, boolean isWhite, boolean classic){
    
    Scanner reader = new Scanner(System.in);  
    
    if (board[getY(selection)][getX(selection)].getName() == "king" && Math.abs(getX(selection) - getX(destination)) == 2){
      if (isWhite){
        if (destination == 27){
          if (board[7][4].getMoved() == false && board[7][0].getMoved() == false && board[7][1] == null && board[7][2] == null && board[7][3] == null){
            board[7][2] = board[7][4];
            board[7][4] = null;
            board[7][3] = board[7][0];
            board[7][0] = null;
          }
        }
        if (destination == 67){
          if (board[7][4].getMoved() == false && board[7][7].getMoved() == false && board[7][5] == null && board[7][6] == null){
            board[7][6] = board[7][4];
            board[7][4] = null;
            board[7][5] = board[7][7];
            board[7][7] = null;
          }
        }
      }
      else{
        if (destination == 17){
          if (board[7][3].getMoved() == false && board[7][0].getMoved() == false && board[7][1] == null && board[7][2] == null){
            board[7][1] = board[7][3];
            board[7][3] = null;
            board[7][2] = board[7][0];
            board[7][0] = null;
          }
        }
        if (destination == 57){
          if (board[7][3].getMoved() == false && board[7][7].getMoved() == false && board[7][6] == null && board[7][5] == null && board[7][4] == null){
            board[7][5] = board[7][3];
            board[7][3] = null;
            board[7][4] = board[7][7];
            board[7][7] = null;
          }
        }
      }
      if (classic)
        System.out.println("\nCastle!\n");
      else
        System.out.println("\n\n                                                                     .d8888b.         d8888  .d8888b.  88888888888 888      8888888888 888 \n" + 
                           "                                                                    d88P  Y88b       d88888 d88P  Y88b     888     888      888        888 \n" + 
                           "                                                                    888    888      d88P888 Y88b.          888     888      888        888 \n" + 
                           "                                                                    888            d88P 888  \"Y888b.       888     888      8888888    888 \n" + 
                           "                                                                    888           d88P  888     \"Y88b.     888     888      888        888 \n" + 
                           "                                                                    888    888   d88P   888       \"888     888     888      888        Y8P \n" + 
                           "                                                                    Y88b  d88P  d8888888888 Y88b  d88P     888     888      888         \"  \n" + 
                           "                                                                     \"Y8888P\"  d88P     888  \"Y8888P\"      888     88888888 8888888888 888 \n\n" 
                          );                                                                    
    }
    else{
      if (board[getY(destination)][getX(destination)] != null){
        if (classic)
          System.out.println("\nCapture!\n");
        else
          System.out.println("\n\n                                                                   .d8888b.          d8888  8888888b.   88888888888  888     888  8888888b.   8888888888  888  \n" + 
                           "                                                                    d88P  Y88b        d88888  888   Y88b      888      888     888  888   Y88b  888         888  \n" + 
                           "                                                                    888    888       d88P888  888    888      888      888     888  888    888  888         888  \n" + 
                           "                                                                    888             d88P 888  888   d88P      888      888     888  888   d88P  8888888     888  \n" + 
                           "                                                                    888            d88P  888  8888888P\"       888      888     888  8888888P\"   888         888  \n" + 
                           "                                                                    888    888    d88P   888  888             888      888     888  888 T88b    888         Y8P  \n" + 
                           "                                                                    Y88b  d88P   d8888888888  888             888      Y88b. .d88P  888  T88b   888          \"   \n" + 
                           "                                                                     \"Y8888P\"    d88P     888  888             888       \"Y88888P\"   888   T88b  8888888888  888  \n\n" 
                          );
      }
    
                             
    //moves piece to destination and captures if required
    board[getY(destination)][getX(destination)] = board[getY(selection)][getX(selection)];
    board[getY(selection)][getX(selection)] = null;
    
    }
    
    //allows a pawn to be promoted to desired piece
    String promotion;
    for (int i = 0; i < 8; i++){
      if (board[0][i] != null && board[0][i].getName().equals("pawn")){
        System.out.println("What piece would you like to promote your pawn into?\n(knight, bishop, rook, queen)");
        promotion = reader.nextLine();
        while (promotion.toLowerCase().equals("knight") == false && promotion.toLowerCase().equals("bishop") == false && promotion.toLowerCase().equals("rook") == false && promotion.toLowerCase().equals("queen") == false){
          System.out.println("Please choose either knight, bishop, rook, or queen.");
          promotion = reader.nextLine();
        }
        if (promotion.toLowerCase().equals("knight"))
          board[0][i] = new Knight(isWhite);
        if (promotion.toLowerCase().equals("bishop"))
          board[0][i] = new Bishop(isWhite);
        if (promotion.toLowerCase().equals("rook"))
          board[0][i] = new Rook(isWhite);
        if (promotion.toLowerCase().equals("queen"))
          board[0][i] = new Queen(isWhite);
      }
    }
    
    return board;
    
  }
  
  //calls rule list
  public static void rules(){
    
    System.out.println("haven't put rules in yet but if you're using this program then i bet you also know how to play chess");
    
  }
  
  //calls control list
  public static void controls(){
    System.out.println("\nControls:\n" +
                       "a - move cursor left\n" +
                       "d - move cursor right\n" +
                       "w - move cursor up\n" +
                       "s - move cursor down\n" +
                       "q - confirm the piece that you want to move\n" +
                       "e - confirm where you want to move your selected piece\n" + 
                       "u - undo move (still bugged i think)\n" +
                       "controls - show controls\n" +
                       "pieces - show piece list for 2D mode\n" +
                       //"rules - show rules\n" +
                       "resign - forfeit match\n" + 
                       "stalemate - end match in draw\n" +
                       "Enter - submit command\n" +
                       "\n***PRO TIP*** - if you want to move your cursor multiple squares at a time as well as select your pieces more efficiently,\n" +
                       "you can type \"aawq\", for example, instead of having to type \"a\", \"a\", \"w\", \"q\", and enter after each letter.\n"
                      );
  }
  
  //calls piece list 
  public static void pieces(boolean classic){
    if (classic)
      System.out.println("Pieces:\n" +
                         "P/p - pawn\n" +
                         "N/n - knight\n" +
                         "B/b - bishop\n" +
                         "R/r - rook\n" +
                         "Q/q - queen\n" +
                         "K/k - king\n" +
                         "Lowercase pieces are white.\n" +
                         "Uppercase pieces are black.\n"
                        );
    else
      System.out.println("The \"empty\" pieces are white, while the \"filled in\" are black.");
  }
  
  
  
  public static int moveCursor(int location, String input, boolean isWhite){
    
    for (int i = 0; i < input.length(); i++){
      
      char command = input.charAt(i);
      
      if (command == 'a'){
        if (location < 10){
          location += 70;
        }
        else 
          location -= 10;
      }
      
      if (command == 'd'){
        if (location >= 70){
          location -= 70;
        }
        else
          location += 10;
      }
      
      if (command == 'w'){
        if (location%10 == 0){
          location += 7;
        }
        else
          location -= 1;
      }
      
      if (command == 's'){
        if (location%10 == 7){
          location -= 7;
        }
        else
          location += 1;
      }
      
    }
    
    return location;
  }
  
  
  
  public static Piece[][] invertBoard(Piece[][] board){
    
    Piece[][] b = new Piece[8][8];
    
    for (int i = 0; i < 8; i++){
      for (int j = 0; j < 8; j++){
        b[j][i] = board[7-j][7-i];
      }
    }
    
    return b;
  }
  
  
  public static int getX(int i){
    return i/10;
  }
  
  public static int getY(int i){
    return i%10;
  }
  
  
  //Beyond here lie perhaps the most insane loops and lines of code you have ever seen...
  //View at your own risk :0
 
  public static void printBoard3D(Piece[][] chessboard, int location, int selection){
    
    String board = "";
    int count = 0;
    String white = " ";
    String black = "-";
    String cursor = "#";
    String selected = "%";
    
    
    for (int y = 0; y < 8; y++){
      for (int k = 0; k < 7; k++){
        for (int z = 0; z < ((55 - count)/7) * 7 + k; z++){
          if (k == 5){
            if (((55 - count)/7 * 7 + k) - z == 2)
              board += "/";
            else
              board += " ";
          }
          else{
            if (k == 6){
              if (((55 - count)/7 * 7 + k) - z <= 4){
                if (((55 - count)/7 * 7 + k) - z <= 2){
                  if (location == y)
                    board += cursor;
                  else{
                    if (selection == y)
                      board += selected;
                    else{
                      if (y%2 == 1)
                        board += black;
                      else
                        board += white;
                    }
                  }
                }
                else {
                  if (((55 - count)/7 * 7 + k) - z == 4)
                    board += "/";
                  else
                    board += " ";
                }
              }
              else
                board += " ";
            }
            else
              board += " ";
          }
        }
        for (int x = 0; x < 8; x++){
          board += printPiece(chessboard[y][x], k, 10*x + y, location, white, black, cursor, selection, selected);
          if (k == 5){
            if (10*x + y == location)
              board += cursor + cursor;
            else{
              if (10*x + y == selection)
                board += selected + selected;
            else{
              if ((x+y)%2 == 0)
                board += white + white;
              else
                board += black + black;
            }
          }
          }
          if (k == 6){
            if (10*x + y == location)
              board += cursor + cursor;
            else{
              if (10*x + y == selection)
                board += selected + selected;
            else{
              if ((x+y)%2 == 0)
                board += white + white;
              else
                board += black + black;
            }
          }
            if (x < 7){
              if (10*(x+1) + y == location)
                board += cursor + cursor;
              else{
                if (10*(x+1) + y == selection)
                  board += selected + selected;
              else{
                if (((x+1)+y)%2 == 0)
                  board += white + white;
                else
                  board += black + black;
              }
            }
          }
          }
        }
        for (int i = 0; i < 10 - 2*k; i++){
          if (k == 0){
            if (y == 0)
              board += "-";
            else{
              if (69 + y == location)
                board += cursor;
              else{
                if (69 + y == selection)
                  board += selected;
                else{
                  if (y%2 == 1)
                    board += black;
                  else
                    board += white;
                }
              }
            }
          }
          else{
            if (70 + y == location)
              board += cursor;
            else{
              if (70 + y == selection)
                board += selected;
              else{
                if (y%2 == 0)
                  board += black;
                else
                  board += white;
              }
            }
          }
        }
        if (k==0 && y==0)
          board += "-,";
        else
          board += " /";
        count++;
        board += "\n";
      }
    }
    
    board += " / ";
    for (int b = 0; b < 8; b++){
      if (location == 10*b + 7){
        for (int q = 0; q < 14; q++){
          board += cursor;
        }
      }
      else{
        if (selection == 10*b + 7){
          for (int q = 0; q < 14; q++){
            board += selected;
          }
        }
        else{
          if (b%2 == 0){
            for (int q = 0; q < 14; q++){
              board += black;
            }
          }
          else
            for (int q = 0; q < 14; q++){
            board += white;
          }
        }
      }
    }
    if (77 == location)
      board += cursor;
    else{
      if (77 == selection)
        board += selected;
      else{
        board += " ";
      }
    }
    board += "/\n'------------------------------------------------------------------------------------------------------------------'\n";
    
    System.out.println(board);
    
  }
  
  public static String printPiece(Piece piece, int i, int k, int c, String white, String black, String cursor, int s, String selected){
    
    String c1;
    String c2;
    String c3;
    String c4;
    
    if ((getY(k)+getX(k))%2 == 1){ 
      c1 = white;
      c2 = black;
      c3 = white;
      c4 = black;
    }
    else{
      c1 = black;
      c2 = white;
      c3 = black;
      c4 = white;
    }
    
    if (getX(k-s) == 1 && getY(k-s) == 0)
      c1 = selected;
    if (getX(k-s) == 0 && getY(k-s) == 0)
      c2 = selected;
    if (getX(k-s) == 0 && getY(k-s) == 1)
      c3 = selected;
    if (getX(k-s) == 1 && getY(k-s) == 1)
      c4 = selected;
    
    if (getX(k-c) == 1 && getY(k-c) == 0)
      c1 = cursor;
    if (getX(k-c) == 0 && getY(k-c) == 0)
      c2 = cursor;
    if (getX(k-c) == 0 && getY(k-c) == 1)
      c3 = cursor;
    if (getX(k-c) == 1 && getY(k-c) == 1)
      c4 = cursor;
    
    
    
    String[] s1 = new String[7];
    s1[0] =  "44444444443333";
    s1[1] =   "11111111222222";
    s1[2] =    "11111122222222";
    s1[3] =     "11112222222222";
    s1[4] =      "11222222222222";
    s1[5] =       "222222222222";
    s1[6] =        "2222222222";
    
    
    String[] s2 = new String[7];
    s2[0] =  "        / 3333";
    s2[1] =   "      / 222222";
    s2[2] =    "    / 22222222";
    s2[3] =     "  / 2222222222";
    s2[4] =      "/ 222222222222";
    s2[5] =       "222222222222";
    s2[6] =        "2222222222";
    
    
    String[] s3 = new String[7];
    s3[0] =  "--------------";
    s3[1] =   "11111111222222";
    s3[2] =    "11111122222222";
    s3[3] =     "11112222222222"; 
    s3[4] =      "11222222222222";
    s3[5] =       "222222222222";
    s3[6] =        "2222222222";
    
    String[] s4 = new String[7];
    s4[0] =  "        ,-----";
    s4[1] =   "      / 222222";
    s4[2] =    "    / 22222222";
    s4[3] =     "  / 2222222222"; 
    s4[4] =      "/ 222222222222";
    s4[5] =       "222222222222";
    s4[6] =        "2222222222";
    
    
    
    
    String[] p = new String[7];
    if (piece == null){
      p[0] = "88888888888888";
      p[1] =  "88888888888888";
      p[2] =   "88888888888888";
      p[3] =    "88888888888888";
      p[4] =     "88888888888888";
      p[5] =      "888888888888"; 
      p[6] =       "8888888888"; 
    }
    else{
      if (piece.getName() == "pawn"){
        p[0] = "88888888888888";
        p[1] =  "88888888888888";
        p[2] =   "888888,44,.888";
        p[3] =    "88888\\33\\ \\888";
        p[4] =     "88888\\11\\/ \\88";
        p[5] =      "8888\\111\\/88"; 
        p[6] =       "8888888888"; 
      }
      else{
        if (piece.getName() == "knight"){
          p[0] = "88888888888888";
          p[1] =  "888888,_____88";
          p[2] =   "8888,/5555/\\88";
          p[3] =    "8888\\' 11\\/888";
          p[4] =     "8888| \\/--,.88";
          p[5] =      "888|____/ /8"; 
          p[6] =       "88\\1111\\/8"; 
        }
        else{
          if (piece.getName() == "bishop"){
            p[0] = "88888888888888";
            p[1] =  "8888888o888888";
            p[2] =   "888888,\\,.8888";
            p[3] =    "88888\\1\\,\\.888";
            p[4] =     "8888\\11\\/ \\.88";
            p[5] =      "888\\111\\/ /8"; 
            p[6] =       "88\\1111\\/8"; 
          }
          else{
            if (piece.getName() == "rook"){
              p[0] = "88888888888888";
              p[1] =  "888888/_//_/\\8";
              p[2] =   "8888/_//_/ /88";
              p[3] =    "888\\1111\\/.888";
              p[4] =     "88888\\1\\/-,.88";
              p[5] =      "888/___\\/ /8"; 
              p[6] =       "88\\1111\\/8"; 
            }
            else{
              if (piece.getName() == "queen"){
                p[0] = "88888,444,~.88";
                p[1] =  "8888\\333\\  \\88";
                p[2] =   "8888\\111\\/8888";
                p[3] =    "88888\\1\\,\\.888";
                p[4] =     "8888\\11\\/ \\.88";
                p[5] =      "888\\111\\/ /8"; 
                p[6] =       "88\\1111\\/8"; 
              }
              else{
                if (piece.getName() == "king"){
                  p[0] = "8888888,4, _.8";
                  p[1] =  "88888_\\3\\_/\\88";
                  p[2] =   "888\\13331\\/888";
                  p[3] =    "88888\\_\\,\\.888";
                  p[4] =     "8888\\11\\/ \\.88";
                  p[5] =      "888\\111\\/ /8"; 
                  p[6] =       "88\\1111\\/8"; 
                }
              }
            }
          }
        }
      }
    }
    
    
    String ree = "";
    String ree2 = p[i];
    
    for (int j = 0; j < ree2.length(); j++){
      
      if (ree2.charAt(j)==('1') || ree2.charAt(j)==('2') || ree2.charAt(j)==('3') || ree2.charAt(j)==('4') || ree2.charAt(j)==('5')){
        if (piece != null){
          if (piece.getColor() == true){
            if (ree2.charAt(j) == ('1'))
              ree += "_";
            if (ree2.charAt(j) == ('2'))
              ree += " ";
            if (ree2.charAt(j) == ('3'))
              ree += " ";
            if (ree2.charAt(j) == ('4'))
              ree += "-";
            if (ree2.charAt(j) == ('5'))
              ree += "_";
          }
          else{
            if (ree2.charAt(j) == ('1'))
              ree += "\\";
            if (ree2.charAt(j) == ('2'))
              ree += "/";
            if (ree2.charAt(j) == ('3'))
              ree += "\\";
            if (ree2.charAt(j) == ('4'))
              ree += ",";
            if (ree2.charAt(j) == ('5'))
              ree += "/";
          }
        }        
      }
      else{
        if (ree2.charAt(j) == ('8')){
          if (k==0){
            if (s4[i].charAt(j) == '2')
              ree += c2;
            else
              ree += s4[i].charAt(j);
          }
          else{
            if (getX(k) == 0){
              if (s2[i].charAt(j) == '2' || s2[i].charAt(j) == '3'){
                if (s2[i].charAt(j) == '2')
                  ree += c2;
                if (s2[i].charAt(j) == '3')
                  ree += c3;
              }
              else
                ree += s2[i].charAt(j);
            }
            else{
              if (getY(k) == 0){
                if (s3[i].charAt(j) == '1' || s3[i].charAt(j) == '2'){
                  if (s3[i].charAt(j) == '1')
                    ree += c1;
                  if (s3[i].charAt(j) == '2')
                    ree += c2;
                }
                else
                  ree += s3[i].charAt(j);
              }
              else{
                if (s1[i].charAt(j) == '1' || s1[i].charAt(j) == '2' || s1[i].charAt(j) == '3' || s1[i].charAt(j) == '4'){
                  if (s1[i].charAt(j) == '1')
                    ree += c1;
                  if (s1[i].charAt(j) == '2')
                    ree += c2;
                  if (s1[i].charAt(j) == '3')
                    ree += c3;
                  if (s1[i].charAt(j) == '4')
                    ree += c4;
                }
                else
                  ree += s1[i].charAt(j);
              }
            }
          }
        }
        else
          ree += ree2.charAt(j);
      }
    }
    
    return ree;
    
  }
  
  
  public static void printBoard(Piece[][] board, int location, boolean isWhite){
    
    String ree = "";
    
    System.out.println(" --------------------------------.");
    
    for (int i = 0; i < 8; i++){
      if (isWhite)
        ree += 8-i;
      else
        ree += i+1;
      for (int j = 0; j < 8; j++){
        ree += "|";
        if ((i+j)%2 == 0)
          ree += " ";
        else
          ree += "~";
        if (board[i][j] == null){
          if ((i+j)%2 == 0)
            ree += " ";
          else
            ree += "~";
        }
        else
          ree += board[i][j].getSymbol();
        if (getX(location) == j && getY(location) == i)
          ree += "<";
        else{
          if ((i+j)%2 == 0)
            ree += " ";
          else
            ree += "~";
        }
      }
      ree += "|\n +---+---+---+---+---+---+---+---|\n";
    }
    
    if (isWhite)
      ree += "   A   B   C   D   E   F   G   H\n\n";
    else
      ree += "   H   G   F   E   D   C   B   A\n\n";
    
    System.out.print(ree);
    
  }
  
  
  
}