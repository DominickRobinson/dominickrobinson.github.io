public class Bishop extends Piece{
  
  public Bishop(boolean isWhite){
    super(isWhite);
    name = "bishop";
    if (color == true)
      symbol = 'b';
    else
      symbol = 'B';
  }
  
}